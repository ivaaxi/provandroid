package com.example.provamobile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var somar : Button = findViewById(R.id.somar)
        var valor1 : EditText = findViewById(R.id.valor1)
        var valor2 : EditText = findViewById(R.id.valor2)

      somar.setOnCLickListenner{
          var resultado

      }
    }
}